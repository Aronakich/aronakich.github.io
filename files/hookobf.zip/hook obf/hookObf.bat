cd /D %~dp0\luajit\
luajit.exe ..\main.lua %*