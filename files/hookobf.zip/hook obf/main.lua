local ffi = require 'ffi'
ffi.cdef("int SetConsoleTitleA(const char* name)")

local function getFilePathFromPathWithoutEx(path)
    return string.match(path, '(.+)%..+$')
end

ffi.C.SetConsoleTitleA("Lua hook load by The Spark blasthack")
os.execute('cls')

local filePath = getFilePathFromPathWithoutEx(arg[1])
local counterLoad = 1

local obfHook = function(code)
	local file = io.open(filePath .. '-' .. counterLoad .. "-hook.luac", "wb")
	counterLoad = counterLoad + 1
    if file then
        file:write(code)
        file:close()
    end
end

load = function(code)
	print('Detect load! ' .. counterLoad)
	obfHook(code)
	return function () end
end

loadstring = function(code)
	print('Detect loadstring! ' .. counterLoad)
	obfHook(code)
	return function () end
end

local fFunction, sErrorText = loadfile(arg[1])
if fFunction then
	local errorHandler = function(err)
		print("Error:")
        print(err)
    end
    
    xpcall(fFunction, errorHandler)
else
	print('Error load script:')
	print(sErrorText)
end
io.read()