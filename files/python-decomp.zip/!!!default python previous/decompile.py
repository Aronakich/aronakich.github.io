import os
import sys
import pathlib

if __name__ == "__main__":
    script = pathlib.Path(sys.argv[1]).absolute()
    filedata = script.read_bytes()
    if filedata[:3] != b'\x1BLJ':
        raise RuntimeError('Invalid LuaJIT bytecode')
    cmd = 'main.py --catch_asserts --file="{0}" --output="{1}-decompiled.lua" && pause'.format(script, os.path.splitext(script)[0])
    os.system(cmd)